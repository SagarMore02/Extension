document.addEventListener("DOMContentLoaded", function () {
    const popupContainer = document.querySelector(".popup-container");
    const leadModal = document.getElementById("leadModal");
    const getDetailsMenu = document.getElementById("two");
    const cancelBtn = document.getElementById("cancelBtn");
    const firstNameInput = document.getElementById("first-name");
    const lastNameInput = document.getElementById("last-name");
    const profileLink = document.getElementById("linkedin-url");
    const saveLead = document.getElementById("saveBtn");
    const openKylas = document.getElementById("three");
    const openLinkedIn = document.getElementById("one");


    getDetailsMenu.addEventListener("click", function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs.length === 0) return;

            // Inject content.js if needed
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ["content.js"]
            }, () => {
                console.log("✅ content.js injected!");

                // Send message to content script to check if on LinkedIn profile
                chrome.tabs.sendMessage(tabs[0].id, { action: "checkLinkedInProfile" }, function (response) {
                    if (chrome.runtime.lastError) {
                        console.error("⚠️ Error:", chrome.runtime.lastError.message);
                        firstNameInput.value = "Error";
                        return;
                    }

                    console.log("📩 Received response from content script:", response);
                    if(response.isProfile) profileLink.value = response.url;
                    if (response.isProfile) {
                        // Now fetch the name from LinkedIn profile
                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInName" }, function (nameResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching name:", chrome.runtime.lastError.message);
                                firstNameInput.value = "Error";
                                return;
                            }
                            if(nameResponse.name){
                            firstNameInput.value = nameResponse.name.split(" ")[0];
                            lastNameInput.value = nameResponse.name.split(" ").slice(1).join(" ");
                            }else{
                                firstNameInput.value = "No Names Found";
                                lastNameInput.value = "";
                            }
                        });

                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInContact" }, function (contactResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching contact info:", chrome.runtime.lastError.message);
                            } else {
                                document.getElementById("email").value = contactResponse.emails[0] || "No Email Found";
                                document.getElementById("company").value=contactResponse.companyName || "No Comapany Found";
                                if(document.getElementById("company").value!=="No Company Found")
                                document.getElementById("company-link").value = contactResponse.websites[0]||"No Company Link Found";
                            }
                        });
                    } else {
                        firstNameInput.value = "NoLinkedInProfile";
                    }
                    popupContainer.style.display = "none";
                    leadModal.style.display = "block";
                });
            });
        });
    });

    saveLead.addEventListener("click",async function(){
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
        let smtg = document.getElementById("email").value.match(emailRegex);

        const firstName = document.getElementById("first-name").value;
        const lastName = document.getElementById("last-name").value;
        const linkedurl=document.getElementById("linkedin-url").value;
        let email=null;
        if(smtg!=null){ 
            email=[
            {
                type: "OFFICE",
                value: smtg[0],
                primary: true
            }
        ];
    }else{
        email=null;
    }
        let company=null;
        if(document.getElementById("company").value!=="No Comapany Found")
            company=document.getElementById("company").value;

        let companylink=null;
        if(document.getElementById("company-link").value!=="No Company Link Found")
            companylink =document.getElementById("company-link").value;

        try{
            
            const response = await fetch('https://api-qa.sling-dev.com/v1/leads/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': 'f2d8d207-51b9-4482-a244-730ac9c39852:4371'
                },
                body: JSON.stringify({
                    ownerId: '11210',
                    firstName: firstName,
                    lastName: lastName,
                    phoneNumbers: null,
                    emails: email,
                    timezone: "Etc/GMT+12",
                    city: "Mumbai",
                    state: "Maharashtra",
                    zipcode: "400001",
                    country: "IN",
                    department: "Sales",
                    dnd: false,
                    facebook: null,
                    twitter: null,
                    linkedIn: linkedurl,
                    address: "123, Example Street",
                    companyName: company,
                    designation: "Manager",
                    companyAddress: "456, Business Avenue",
                    companyCity: "Mumbai",
                    companyState: "Maharashtra",
                    companyZipcode: "400002",
                    companyCountry: "IN",
                    companyEmployees: null,
                    companyAnnualRevenue: null,
                    companyWebsite: companylink,
                    companyIndustry: null,
                    companyBusinessType: null,
                    requirementName: null,
                    requirementCurrency: "INR",
                    requirementBudget: null,
                    campaign: null,
                    source: null,
                    customFieldValues: {}
                })
            });
        
            const result = await response.json();
            if (response.ok) {
                alert("Data successfully saved!");
                console.log("Response:", result);
            } else {
                console.error("Error response:", result);
                alert(`Error: ${result.message || "Something went wrong"}`);
            }


        }catch(error){
            console.error('Error saving data:', error);
            alert('Error saving data');
        }

        leadModal.style.display = "none";
        popupContainer.style.display = "block";


    });

    cancelBtn.addEventListener("click", function () {
        leadModal.style.display = "none";
        popupContainer.style.display = "block";
    });


    openKylas.addEventListener("click",function(){
        const url = "https://app-qa.sling-dev.com/sales/leads/list"; // Replace with your URL
        window.open(url, "_blank");

    });

    openLinkedIn.addEventListener("click",function(){
        const linkedInPeopleSearchURL = "https://www.linkedin.com/search/results/people/";
        window.open(linkedInPeopleSearchURL, "_blank");

    });

});
