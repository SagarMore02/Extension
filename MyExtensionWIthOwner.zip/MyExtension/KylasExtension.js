document.addEventListener("DOMContentLoaded", function () {
    addPopupToBody();

    let selectedUserId=-1;
    let company=null;
    let apiaccessToken=null;
    let apiemail=null;
    let apipassword=null;
    let apiKey=null;

    document.body.addEventListener("click",function(event){
        if(event.target.id==="Usernumber") Usernumber();
        if(event.target.id==="two") two();
        if(event.target.id==="saveBtn") saveBtn();
        if(event.target.id==="cancelBtn") cancelBtn();
        if(event.target.id==="three") three();
        if(event.target.id==="one") one();

    });
    async function extractNamesAndIds() {
        try {
            // Fetch response (Replace with actual API URL if needed)
            const response = await fetch("https://api-qa.sling-dev.com/v1/users/search?sort=updatedAt,desc&page=0&size=10", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "api-key": "f2d8d207-51b9-4482-a244-730ac9c39852:4371" // Add if required
                },
                body:JSON.stringify({
                    "jsonRule": null
                })
            });
    
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
    
            const data = await response.json(); // Convert response to JSON
    
            // Extract firstName, lastName, and id from the content array
            if (data.content && Array.isArray(data.content)) {
                const extractedData = data.content.map(person => ({
                    firstName: person.firstName || "N/A",
                    lastName: person.lastName || "N/A",
                    id: person.id || "N/A"
                }));
    
                //alert("Extracted Data:"+extractedData.length);
                return extractedData;
            } else {
                console.error("No content found in response.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    }
    
    
    function Usernumber() {
        selectedUserId = document.getElementById("Usernumber").value; // Get selected user ID
    };




    async function two() {
        chrome.tabs.query({ active: true, currentWindow: true },async function (tabs) {
            if (tabs.length === 0) return;

            // Inject content.js if neededs
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ["content.js"]
            }, () => {
                console.log("✅ content.js injected!");

                // Send message to content script to check if on LinkedIn profile
                chrome.tabs.sendMessage(tabs[0].id, { action: "checkLinkedInProfile" }, async function (response) {
                    if (chrome.runtime.lastError) {
                        console.error("⚠️ Error:", chrome.runtime.lastError.message);
                        document.getElementById("first-name").value = "Error";
                        return;
                    }

                    console.log("📩 Received response from content script:", response);
                    if(response.isProfile) {
                        const popupContainer = document.querySelector(".popup-container");
                        addLeadModal();
                        popupContainer.remove();
                        document.getElementById("linkedin-url").value = response.url;
                    }
                    if (response.isProfile) {

                        let Users=await extractNamesAndIds();
                        //alert("Lengthis"+Users.length);
                        const userDropdown = document.getElementById("Usernumber");

                        // Clear existing options
                        userDropdown.innerHTML = '<option value="">Select User</option>';
                    
                        // Populate dropdown with user data
                        Users.forEach(user => {
                            let option = document.createElement("option");
                            option.value = user.id;  // Use user ID as value
                            option.textContent = `${user.firstName} ${user.lastName}`; // Display full name
                            userDropdown.appendChild(option);
                        });


                        // Now fetch the name from LinkedIn profile
                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInName" }, function (nameResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching name:", chrome.runtime.lastError.message);
                                document.getElementById("first-name").value = "Error";
                                return;
                            }
                            if(nameResponse.name){
                                document.getElementById("first-name").value = nameResponse.name.split(" ")[0];
                                document.getElementById("last-name").value = nameResponse.name.split(" ").slice(1).join(" ");
                            }else{
                                document.getElementById("first-name").value = "No Names Found";
                                document.getElementById("last-name").value = "";
                            }
                        });

                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInContact" }, function (contactResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching contact info:", chrome.runtime.lastError.message);
                            } else {
                                document.getElementById("email").value = contactResponse.emails[0] || "No Email Found";
                                document.getElementById("company").value=contactResponse.companyName || "No Comapany Found";
                                if(document.getElementById("company").value!=="No Company Found")
                                document.getElementById("company-link").value = contactResponse.websites[0]||"No Company Link Found";
                            }
                        });
                    } else {
                        document.getElementById("first-name").value = "NoLinkedInProfile";
                    }
                    //popupContainer.style.display = "none";
                    //leadModal.style.display = "block";
                });
            });
        });
    };

    async function saveBtn(){
        if(selectedUserId==-1){
            alert("Please Select a Valid User To Create Lead!!");
            return;
        }
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
        let smtg = document.getElementById("email").value.match(emailRegex);

        const firstName = document.getElementById("first-name").value;
        const lastName = document.getElementById("last-name").value;
        const linkedurl=document.getElementById("linkedin-url").value;
        let email=null;
        if(smtg!=null){ 
            email=[
            {
                type: "OFFICE",
                value: smtg[0],
                primary: true
            }
        ];
        }else{
        email=null;
        }
        
            if(document.getElementById("company").value!=="No Comapany Found")
            company=document.getElementById("company").value;

            let companylink=null;
            if(document.getElementById("company-link").value!=="No Company Link Found")
            companylink =document.getElementById("company-link").value;

            try{
            
            const response = await fetch('https://api-qa.sling-dev.com/v1/leads/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': 'f2d8d207-51b9-4482-a244-730ac9c39852:4371'
                },
                body: JSON.stringify({
                    ownerId: selectedUserId,
                    firstName: firstName,
                    lastName: lastName,
                    phoneNumbers: null,
                    emails: email,
                    timezone: "Etc/GMT+12",
                    city: "Mumbai",
                    state: "Maharashtra",
                    zipcode: "400001",
                    country: "IN",
                    department: "Sales",
                    dnd: false,
                    facebook: null,
                    twitter: null,
                    linkedIn: linkedurl,
                    address: "123, Example Street",
                    companyName: company,
                    designation: "Manager",
                    companyAddress: "456, Business Avenue",
                    companyCity: "Mumbai",
                    companyState: "Maharashtra",
                    companyZipcode: "400002",
                    companyCountry: "IN",
                    companyEmployees: null,
                    companyAnnualRevenue: null,
                    companyWebsite: companylink,
                    companyIndustry: null,
                    companyBusinessType: null,
                    requirementName: null,
                    requirementCurrency: "INR",
                    requirementBudget: null,
                    campaign: null,
                    source: null,
                    customFieldValues: {}
                })
            });
        
            const result = await response.json();
            if (response.ok) {
                alert("Data successfully saved!");
                console.log("Response:", result);
            } else {
                console.error("Error response:", result);
                alert(`Error: ${result.message || "Something went wrong"}`);
            }


            }catch(error){
            console.error('Error saving data:', error);
            alert('Error saving data');
            }
            const leadModal = document.getElementById("leadModal");
            // leadModal.style.display = "none";
            // popupContainer.style.display = "block";
            leadModal.remove();
            addPopupToBody();
            //leadModal.style.display = "none";
            //document.body.appendChild(popupContainer);//style.display = "block";

    };

    function cancelBtn() {
        const leadModal = document.getElementById("leadModal");
        leadModal.remove();
        addPopupToBody();
        //leadModal.style.display = "none";
        //document.body.appendChild(popupContainer);//style.display = "block";
    };


    function three(){
        const url = "https://app-qa.sling-dev.com/sales/leads/list"; // Replace with your URL
        window.open(url, "_blank");

    };

    function one(){
        const linkedInPeopleSearchURL = "https://www.linkedin.com/search/results/people/";
        window.open(linkedInPeopleSearchURL, "_blank");

    };





//HTML CODE::::::::::::::


function addLeadModal() {
    // Create a div element
    const modalDiv = document.createElement("div");
    modalDiv.className = "modal";
    modalDiv.id = "leadModal";
    //modalDiv.style.display = "none";

    // Set innerHTML of the modal
    modalDiv.innerHTML = `
        <div class="header">Add Lead</div>
        <div class="form-container">
            <div class="form-group">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name">
            </div>
            <div class="form-group">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name">
            </div>
            <div class="form-group">
                <label for="linkedin-url">LinkedIn URL</label>
                <input type="text" id="linkedin-url">
            </div>
            <div class="form-group">
                <label for="company">Company</label>
                <input type="text" id="company">
            </div>
            <div class="form-group">
                <label for="company-link">Company Link</label>
                <input type="text" id="company-link">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email">
            </div>
            <div class="form-group">
                <label for="Users">Created By</label>
                <select id="Usernumber" class="dropdown">
                    <option value="-1">Select User</option>
                </select>
            </div>
        </div>
        <div class="button-group">
            <button class="btn cancel" id="cancelBtn">Cancel</button>
            <button class="btn save" id="saveBtn">Save Lead</button>
        </div>
    `;

    // Append modal to the body
    document.body.appendChild(modalDiv);
}



function addPopupToBody() {
    // Create a new div element
    const popupContainer = document.createElement("div");
    popupContainer.classList.add("popup-container"); // Add class

    // Set the inner HTML for the popup
    popupContainer.innerHTML = `
        <div class="header">
            <img src="KylasLogo.png" alt="Kylas Logo" class="logo">
            <div class="title-container">
                <h3>Kylas Surfer</h3>
                <p>Email Finder & LinkedIn Data Scraper</p>
            </div>
        </div>
        <ul class="menu">
            <li id="one" class="menu-item">Open LinkedIn people search</li>
            <li id="two" class="menu-item">Get Details From Profile</li>
            <li id="three" class="menu-item">Open Kylas web app</li>
        </ul>
    `;

    // Append the popup container to the body
    document.body.appendChild(popupContainer);
}













});
