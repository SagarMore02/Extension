document.addEventListener("DOMContentLoaded", function () {
    let apiKey=null;
    let selectedUserId=-1;
    let company=null;
    let apiemail=null;
    let apipassword=null;
   
    myInitialize();
    function myInitialize(){

        if(localStorage.getItem("latestlogin")!=null){
            let latestlogin = localStorage.getItem("latestlogin");
            apiemail=latestlogin;
            let latestapikey=JSON.parse(localStorage.getItem(latestlogin));
            apiKey=latestapikey.apikey;
        }
        if(apiKey==null || apiKey === undefined){
            addLoginForm();
        }else{
            addPopupToBody();
        }
    }

    function Logout(){
        localStorage.removeItem("latestlogin");
        localStorage.removeItem(apiemail);
        apiKey=null;
        apiemail=null;
        apipassword=null;
        const popupContainer = document.querySelector(".popup-container");
        popupContainer.remove();
        addLoginForm();
    }




    //wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
    async function login() {
        // if(localStorage.getItem("latestlogin")!=null){
        //     let latestlogin = localStorage.getItem("latestlogin");
        //     let latestapikey=JSON.parse(localStorage.getItem(latestlogin));
        //     alert("Api key is : "+latestapikey.apikey);
        // }
        apiemail = document.getElementById("apiemail").value;
        apipassword = document.getElementById("apipassword").value;
        
        if (!apiemail || !apipassword) {
            alert("Please enter email and password.");
            return;
        }
        try {
            const response = await fetch("https://api-qa.sling-dev.com/v1/users/login", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ "email":apiemail, "password":apipassword })
            });

            if (!response.ok) {
                throw new Error("Login failed. Check your credentials.");
            }

            let myKylasApiKey = localStorage.getItem(apiemail);
            if (myKylasApiKey) {
            try {
                myKylasApiKey = JSON.parse(myKylasApiKey);
                apikey=myKylasApiKey.apikey;
                document.getElementById("myloginContainer").remove();
                addPopupToBody();
                //alert("Api Key Exists " + myKylasApiKey.email);
                return;
            } catch (error) {
                console.error("Error parsing JSON from localStorage:", error);
                localStorage.removeItem(apiemail); // Remove corrupt data
            }
        }


            const data = await response.json(); // Get JSON response
            const token = data.token; // Extract JWT token
            console.log("Here:- "+token)
            if (!token) {
                throw new Error("Token not found in response.");
            }

            // Decode JWT and extract apiaccessToken
            const apiaccessToken = "Bearer "+getapiAccessToken(token);

            await getApiKey(apiaccessToken);
            document.getElementById("myloginContainer").remove();
            addPopupToBody();
            ///alert(apiaccessToken); // Show access token in alert

        } catch (error) {
            alert("Error: " + error.message);
        }
    }

    async function getApiKey(apiaccessToken){

        const response = await fetch("https://api-qa.sling-dev.com/v1/api-keys/kylas-app-key", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization":apiaccessToken
                }
            });
            if (!response.ok) {
                throw new Error("Login failed.");
            }

            const data = await response.json(); // Get JSON response
            apikey = data.apiKey; // Extract JWT token

            if (!apikey) {
                throw new Error("Token not found in response.");
            }
            localStorage.setItem("latestlogin",apiemail);
            localStorage.setItem(apiemail,JSON.stringify({email:apiemail,password:apipassword,apikey:apikey}));
            //alert("Api Key is: "+apikey);


    }


    function getapiAccessToken(jwt) {
        try {
            const parts = jwt.split(".");
            if (parts.length !== 3) {
                throw new Error("Invalid JWT format");
            }
            const payload = JSON.parse(atob(parts[1])); // Decode Base64 payload
            console.log(payload);
            return payload.data?.accessToken || "No access token found";
        } catch (error) {
            console.error("JWT Decoding Error:", error);
            return "Error decoding token";
        }
    }
    
    //wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww


    document.body.addEventListener("click",async function(event){
        if(event.target.id==="Usernumber") Usernumber();
        if(event.target.id==="two") two();
        if(event.target.id==="saveBtn") saveBtn();
        if(event.target.id==="cancelBtn") cancelBtn();
        if(event.target.id==="three") three();
        if(event.target.id==="one") one();
        if(event.target.id==="four") Logout();
        if(event.target.id==="loginButton") login();

    });
    async function extractNamesAndIds() {
        try {
            // Fetch response (Replace with actual API URL if needed)
            const response = await fetch("https://api-qa.sling-dev.com/v1/users/search?sort=updatedAt,desc&page=0&size=10", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "api-key": apiKey // Add if required
                },
                body:JSON.stringify({
                    "jsonRule": null
                })
            });
    
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
    
            const data = await response.json(); // Convert response to JSON
    
            // Extract firstName, lastName, and id from the content array
            if (data.content && Array.isArray(data.content)) {
                const extractedData = data.content.map(person => ({
                    firstName: person.firstName || "N/A",
                    lastName: person.lastName || "N/A",
                    id: person.id || "N/A"
                }));
    
                //alert("Extracted Data:"+extractedData.length);
                return extractedData;
            } else {
                console.error("No content found in response.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    }
    
    
    function Usernumber() {
        selectedUserId = document.getElementById("Usernumber").value; // Get selected user ID
    };




    async function two() {
        chrome.tabs.query({ active: true, currentWindow: true },async function (tabs) {
            if (tabs.length === 0) return;

            // Inject content.js if neededs
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ["content.js"]
            }, () => {
                console.log("✅ content.js injected!");

                // Send message to content script to check if on LinkedIn profile
                chrome.tabs.sendMessage(tabs[0].id, { action: "checkLinkedInProfile" }, async function (response) {
                    if (chrome.runtime.lastError) {
                        console.error("⚠️ Error:", chrome.runtime.lastError.message);
                        document.getElementById("first-name").value = "Error";
                        return;
                    }

                    console.log("📩 Received response from content script:", response);
                    if(response.isProfile) {
                        const popupContainer = document.querySelector(".popup-container");
                        addLeadModal();
                        popupContainer.remove();
                        document.getElementById("linkedin-url").value = response.url;
                    }
                    if (response.isProfile) {

                        let Users=await extractNamesAndIds();
                        //alert("Lengthis"+Users.length);
                        const userDropdown = document.getElementById("Usernumber");

                        // Clear existing options
                        userDropdown.innerHTML = '<option value="">Select User</option>';
                    
                        // Populate dropdown with user data
                        Users.forEach(user => {
                            let option = document.createElement("option");
                            option.value = user.id;  // Use user ID as value
                            option.textContent = `${user.firstName} ${user.lastName}`; // Display full name
                            userDropdown.appendChild(option);
                        });


                        // Now fetch the name from LinkedIn profile
                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInName" }, function (nameResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching name:", chrome.runtime.lastError.message);
                                document.getElementById("first-name").value = "Error";
                                return;
                            }
                            if(nameResponse.name){
                                document.getElementById("first-name").value = nameResponse.name.split(" ")[0];
                                document.getElementById("last-name").value = nameResponse.name.split(" ").slice(1).join(" ");
                            }else{
                                document.getElementById("first-name").value = "No Names Found";
                                document.getElementById("last-name").value = "";
                            }
                        });

                        chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeLinkedInContact" }, function (contactResponse) {
                            if (chrome.runtime.lastError) {
                                console.error("⚠️ Error fetching contact info:", chrome.runtime.lastError.message);
                            } else {
                                document.getElementById("email").value = contactResponse.emails[0] || "No Email Found";
                                document.getElementById("company").value=contactResponse.companyName || "No Comapany Found";
                                if(document.getElementById("company").value!=="No Company Found")
                                document.getElementById("company-link").value = contactResponse.websites[0]||"No Company Link Found";
                            }
                        });
                    } else {
                        document.getElementById("first-name").value = "NoLinkedInProfile";
                    }
                    //popupContainer.style.display = "none";
                    //leadModal.style.display = "block";
                });
            });
        });
    };

    async function saveBtn(){
        if(selectedUserId==-1){
            alert("Please Select a Valid User To Create Lead!!");
            return;
        }
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
        let smtg = document.getElementById("email").value.match(emailRegex);

        const firstName = document.getElementById("first-name").value;
        const lastName = document.getElementById("last-name").value;
        const linkedurl=document.getElementById("linkedin-url").value;
        let email=null;
        if(smtg!=null){ 
            email=[
            {
                type: "OFFICE",
                value: smtg[0],
                primary: true
            }
        ];
        }else{
        email=null;
        }
        
            if(document.getElementById("company").value!=="No Comapany Found")
            company=document.getElementById("company").value;

            let companylink=null;
            if(document.getElementById("company-link").value!=="No Company Link Found")
            companylink =document.getElementById("company-link").value;

            try{
            
            const response = await fetch('https://api-qa.sling-dev.com/v1/leads/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': apiKey
                },
                body: JSON.stringify({
                    ownerId: selectedUserId,
                    firstName: firstName,
                    lastName: lastName,
                    phoneNumbers: null,
                    emails: email,
                    timezone: "Etc/GMT+12",
                    city: "Mumbai",
                    state: "Maharashtra",
                    zipcode: "400001",
                    country: "IN",
                    department: "Sales",
                    dnd: false,
                    facebook: null,
                    twitter: null,
                    linkedIn: linkedurl,
                    address: "123, Example Street",
                    companyName: company,
                    designation: "Manager",
                    companyAddress: "456, Business Avenue",
                    companyCity: "Mumbai",
                    companyState: "Maharashtra",
                    companyZipcode: "400002",
                    companyCountry: "IN",
                    companyEmployees: null,
                    companyAnnualRevenue: null,
                    companyWebsite: companylink,
                    companyIndustry: null,
                    companyBusinessType: null,
                    requirementName: null,
                    requirementCurrency: "INR",
                    requirementBudget: null,
                    campaign: null,
                    source: null,
                    customFieldValues: {}
                })
            });
        
            const result = await response.json();
            if (response.ok) {
                alert("Data successfully saved!");
                console.log("Response:", result);
            } else {
                console.error("Error response:", result);
                alert(`Error: ${result.message || "Something went wrong"}`);
            }


            }catch(error){
            console.error('Error saving data:', error);
            alert('Error saving data');
            }
            const leadModal = document.getElementById("leadModal");
            // leadModal.style.display = "none";
            // popupContainer.style.display = "block";
            leadModal.remove();
            addPopupToBody();
            //leadModal.style.display = "none";
            //document.body.appendChild(popupContainer);//style.display = "block";

    };

    function cancelBtn() {
        const leadModal = document.getElementById("leadModal");
        leadModal.remove();
        addPopupToBody();
        //leadModal.style.display = "none";
        //document.body.appendChild(popupContainer);//style.display = "block";
    };


    function three(){
        const url = "https://app-qa.sling-dev.com/sales/leads/list"; // Replace with your URL
        window.open(url, "_blank");

    };

    function one(){
        const linkedInPeopleSearchURL = "https://www.linkedin.com/search/results/people/";
        window.open(linkedInPeopleSearchURL, "_blank");

    };





//HTML CODE::::::::::::::


function addLeadModal() {
    // Create a div element
    const modalDiv = document.createElement("div");
    modalDiv.className = "modal";
    modalDiv.id = "leadModal";
    //modalDiv.style.display = "none";

    // Set innerHTML of the modal
    modalDiv.innerHTML = `
        <div class="header">Add Lead</div>
        <div class="form-container">
            <div class="form-group">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name">
            </div>
            <div class="form-group">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name">
            </div>
            <div class="form-group">
                <label for="linkedin-url">LinkedIn URL</label>
                <input type="text" id="linkedin-url">
            </div>
            <div class="form-group">
                <label for="company">Company</label>
                <input type="text" id="company">
            </div>
            <div class="form-group">
                <label for="company-link">Company Link</label>
                <input type="text" id="company-link">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email">
            </div>
            <div class="form-group">
                <label for="Users">Created By</label>
                <select id="Usernumber" class="dropdown">
                    <option value="-1">Select User</option>
                </select>
            </div>
        </div>
        <div class="button-group">
            <button class="btn cancel" id="cancelBtn">Cancel</button>
            <button class="btn save" id="saveBtn">Save Lead</button>
        </div>
    `;

    // Append modal to the body
    document.body.appendChild(modalDiv);
}



function addPopupToBody() {
    // Create a new div element
    const popupContainer = document.createElement("div");
    popupContainer.classList.add("popup-container"); // Add class

    // Set the inner HTML for the popup
    popupContainer.innerHTML = `
        <div class="header">
            <img src="KylasLogo.png" alt="Kylas Logo" class="logo">
            <div class="title-container">
                <h3>Kylas Surfer</h3>
                <p>Logged In With:${apiemail || 'Unknown'}</p>
            </div>
        </div>
        <ul class="menu">
            <li id="one" class="menu-item">Open LinkedIn people search</li>
            <li id="two" class="menu-item">Get Details From Profile</li>
            <li id="three" class="menu-item">Open Kylas web app</li>
            <li id="four" class="menu-item">Logout</li>
        </ul>
    `;

    // Append the popup container to the body
    document.body.appendChild(popupContainer);
}


function addLoginForm() {
    // Create the container div
    const loginContainer = document.createElement("div");
    loginContainer.id = "myloginContainer";
    loginContainer.classList.add("login-container");

    // Set the inner HTML for the login form
    loginContainer.innerHTML = `
        <h2>Kylas Login</h2>
        <input class="login-input" type="text" id="apiemail" placeholder="email">
        <input class="login-input" type="password" id="apipassword" placeholder="Password">
        <button class="login-button" id="loginButton">Login</button>
    `;
    // Append to the body
    document.body.appendChild(loginContainer);
}










});
